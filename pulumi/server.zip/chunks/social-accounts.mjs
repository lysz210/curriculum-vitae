import { d as defineEventHandler, u as useStorage } from './nitro/aws-lambda.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import '@aws-sdk/client-dynamodb';
import '@aws-sdk/lib-dynamodb';
import 'lodash';
import 'luxon';

const socialAccounts = defineEventHandler(async (event) => {
  const i18nStorage = useStorage("i18n");
  return i18nStorage.getItem("en:me:social-accounts:");
});

export { socialAccounts as default };
//# sourceMappingURL=social-accounts.mjs.map
