import { d as defineEventHandler, u as useStorage, g as getRouterParam } from './nitro/aws-lambda.mjs';
import _ from 'lodash';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import '@aws-sdk/client-dynamodb';
import '@aws-sdk/lib-dynamodb';
import 'luxon';

const workExperiences = defineEventHandler(async (event) => {
  const i18nStorage = useStorage("i18n");
  return i18nStorage.getItem(`${getRouterParam(event, "lang")}:me:work-experiences:`).then(
    (response) => Array.isArray(response) ? _.reverse(_.sortBy(response, ["from"])) : response
  );
});

export { workExperiences as default };
//# sourceMappingURL=work-experiences.mjs.map
