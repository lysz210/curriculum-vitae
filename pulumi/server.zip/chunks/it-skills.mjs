import { d as defineEventHandler, u as useStorage, g as getRouterParam } from './nitro/aws-lambda.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import '@aws-sdk/client-dynamodb';
import '@aws-sdk/lib-dynamodb';
import 'lodash';
import 'luxon';

const itSkills = defineEventHandler(async (event) => {
  const i18nStorage = useStorage("i18n");
  return i18nStorage.getItem(`${getRouterParam(event, "lang")}:me:knowledge:it-skills`);
});

export { itSkills as default };
//# sourceMappingURL=it-skills.mjs.map
