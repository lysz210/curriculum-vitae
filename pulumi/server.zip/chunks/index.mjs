import { d as defineEventHandler, u as useStorage, g as getRouterParam } from './nitro/aws-lambda.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import '@aws-sdk/client-dynamodb';
import '@aws-sdk/lib-dynamodb';
import 'lodash';
import 'luxon';

const index = defineEventHandler(async (event) => {
  const i18nStorage = useStorage("i18n");
  return i18nStorage.getItem(`${getRouterParam(event, "lang")}:me:index.yaml`).then((response) => {
    if (Array.isArray(response)) {
      return response[0];
    }
    return response || null;
  });
});

export { index as default };
//# sourceMappingURL=index.mjs.map
