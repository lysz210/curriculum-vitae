const client_manifest = {
  "_VList.!~{00f}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VList.Fzzgr5NL.css",
    "src": "_VList.!~{00f}~.js"
  },
  "_VList.PAMY2WPw.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VList.Fzzgr5NL.css"
    ],
    "file": "VList.PAMY2WPw.js",
    "imports": [
      "_ssrBoot.QshE8GnK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "VList.Fzzgr5NL.css": {
    "file": "VList.Fzzgr5NL.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_group.6IMYieLB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "group.6IMYieLB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.8Qh44AVz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.8Qh44AVz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ssrBoot.!~{00e}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ssrBoot.Tr9jNLci.css",
    "src": "_ssrBoot.!~{00e}~.js"
  },
  "_ssrBoot.QshE8GnK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ssrBoot.Tr9jNLci.css"
    ],
    "file": "ssrBoot.QshE8GnK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "ssrBoot.Tr9jNLci.css": {
    "file": "ssrBoot.Tr9jNLci.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_vue.f36acd1f._rG_Wvxn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f._rG_Wvxn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "lang/en.yaml": {
    "resourceType": "script",
    "module": true,
    "prefetch": false,
    "preload": false,
    "file": "en.04DHWWam.js",
    "isDynamicEntry": true,
    "src": "lang/en.yaml"
  },
  "lang/it.yaml": {
    "resourceType": "script",
    "module": true,
    "prefetch": false,
    "preload": false,
    "file": "it.itekVVYW.js",
    "isDynamicEntry": true,
    "src": "lang/it.yaml"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "default.TdxcPdC2.css"
    ],
    "file": "default.2b76GQ4W.js",
    "imports": [
      "_nuxt-link.8Qh44AVz.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_ssrBoot.QshE8GnK.js",
      "_group.6IMYieLB.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.TdxcPdC2.css": {
    "file": "default.TdxcPdC2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "error-404.qFGwA4uS.css"
    ],
    "file": "error-404.wbLqcHB0.js",
    "imports": [
      "_nuxt-link.8Qh44AVz.js",
      "_vue.f36acd1f._rG_Wvxn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.qFGwA4uS.css": {
    "file": "error-404.qFGwA4uS.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "error-500.V0P2JAtD.css"
    ],
    "file": "error-500.R2MYUDaY.js",
    "imports": [
      "_vue.f36acd1f._rG_Wvxn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.V0P2JAtD.css": {
    "file": "error-500.V0P2JAtD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.Iacyg5Pv.css"
    ],
    "dynamicImports": [
      "layouts/default.vue",
      "lang/en.yaml",
      "lang/it.yaml",
      "vue-i18n.config.ts?hash=ebc67d6d&config=1",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.yJ4DOa9-.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.Iacyg5Pv.css": {
    "file": "entry.Iacyg5Pv.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/education.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "education._bqBsArA.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ssrBoot.QshE8GnK.js",
      "_VList.PAMY2WPw.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/education.vue"
  },
  "pages/experience.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "experience.32nrR-tk.css"
    ],
    "file": "experience.NTd9N4io.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ssrBoot.QshE8GnK.js",
      "_VList.PAMY2WPw.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/experience.vue"
  },
  "experience.32nrR-tk.css": {
    "file": "experience.32nrR-tk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.DHY-S-iO.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/personal-skills.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "personal-skills.x23nhXFT.css"
    ],
    "file": "personal-skills.WATiJGiR.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ssrBoot.QshE8GnK.js",
      "_VList.PAMY2WPw.js",
      "_group.6IMYieLB.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/personal-skills.vue"
  },
  "personal-skills.x23nhXFT.css": {
    "file": "personal-skills.x23nhXFT.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "vue-i18n.config.ts?hash=ebc67d6d&config=1": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue-i18n.config.BtJ8zFDN.js",
    "isDynamicEntry": true,
    "src": "vue-i18n.config.ts?hash=ebc67d6d&config=1"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
