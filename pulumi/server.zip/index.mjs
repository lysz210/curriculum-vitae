globalThis._importMeta_={url:import.meta.url,env:process.env};export { o as handler } from './chunks/nitro/aws-lambda.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import '@aws-sdk/client-dynamodb';
import '@aws-sdk/lib-dynamodb';
import 'lodash';
import 'luxon';
//# sourceMappingURL=index.mjs.map
